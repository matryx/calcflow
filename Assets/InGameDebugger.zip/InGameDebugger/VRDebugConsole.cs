﻿using UnityEngine;

using System.Collections.Generic;

using Nanome.Core;
using Nanome.Core.Extension;

namespace Nanome.UI.Debugger
{

    public class VRDebugConsole : Nanome.Core.Behaviour
    {
        [HideInInspector]
        public ConsoleItemDetail activeDetailPanel = null;

        List<ConsoleItem> debugItems = new List<ConsoleItem>();
        bool isOpen = false;

        void Awake()
        {
            PlayDebug.OnNewLog += AddConsoleItem;
            this.subscribe("DebugConsole", delegate (string type, object payload)
            {
                if (type == "ToggleConsole")
                {
                    if (isOpen)
                    {
                        transform.localScale = Vector3.zero;
                        isOpen = false;
                    }
                    else
                    {
                        transform.localScale = new Vector3(0.39f, 0.3f, 0.01f);
                        isOpen = true;
                    }
                }
            });
        }

        public void AddConsoleItem(object[] payload)
        {
            var message = (string)payload[0];
            var formattedStackTrace = (List<Tuple<string, string, string>>)payload[1];
            if (debugItems.Count == 10)
            {
                Reorganize();
            }

            var orderNumber = debugItems.Count;
            var cItemObj = Make.objectWithPrefab("ConsoleItem", transform);
            cItemObj.transform.localPosition = new Vector3(0f, 0.356f - orderNumber * 0.082f, -0.57f);
            cItemObj.transform.localScale = new Vector3(0.95f, 0.07f, 0.45f);
            var item = cItemObj.GetComponent<ConsoleItem>();
            item.Initialize(message, formattedStackTrace, this);
            debugItems.Add(item);
            // Create an item and populate with info from formattedStackTrace
        }

        void Reorganize()
        {
            foreach (var item in debugItems)
            {
                item.transform.localPosition += new Vector3(0f, 0.082f, 0f);
            }
            var itemToRemove = debugItems[0];
            debugItems.RemoveAt(0);
            Destroy(itemToRemove.gameObject);
        }

        void OnDisable()
        {
            PlayDebug.OnNewLog -= AddConsoleItem;    
        }
    }

}
