﻿using UnityEngine;

using System.Collections.Generic;

using Nanome.Core.Extension;
using Nanome.Behaviour;

using TMPro;

namespace Nanome.UI.Debugger
{

    public class ConsoleItemDetail : Nanome.Core.Behaviour
    {

        public bool remainOpen = false;
        public TextMeshPro debugMessage;
        public TextMeshPro stackTraceMessage;
        public GameObject stBG;
        public GameObject panelBG;

        public void Enable()
        {
            gameObject.SetActive(true);
        }

        public void Disable()
        {
            if (remainOpen == false)
            {
                gameObject.SetActive(false);
            }
        }

        public void SetMessage(string message)
        {
            debugMessage.SetText(message);
        }

        public void SetStackTrace(List<Tuple<string, string, string>> data)
        {
            var finalString = "";
            foreach (var line in data)
            {
                finalString += line.Item1 + "\n<mark=#3399ff70>" + line.Item2 + "</mark>\n" + line.Item3 + "\n\t\t\t------\n";
            }
            ResizeWindow(data.Count * 5 + 1);
            stackTraceMessage.SetText(finalString);
        }

        void ResizeWindow(int numLines)
        {
            stBG.transform.localPosition = new Vector3(0, 0.285f - 0.016f * numLines, -0.57f);
            stBG.transform.localScale = new Vector3(0.95f, 0.035f * numLines, 0.435f);
            panelBG.transform.localPosition = new Vector3(0f, 0.3948f - 0.0175f * numLines, 0f);
            panelBG.transform.localScale = new Vector3(1, 0.210f + 0.035f * numLines, 0f);
        }

    } 

}
