﻿using UnityEngine;

using System.Collections;
using System.Collections.Generic;

using Nanome.Core.Extension;
using Nanome.Behaviour;
using Nanome.UI.Tools;

using TMPro;

namespace Nanome.UI.Debugger
{

    [RequireComponent(typeof(Nanome.Behaviour.BaseUserControl))]
    public class ConsoleItem : ActionableObject
    {

        Animator animator;
        TextMeshPro tmpro;
        ConsoleItemDetail details;

        public void Initialize(string debugString, List<Tuple<string, string, string>> data, VRDebugConsole console)
        {
            tmpro = GetComponentInChildren<TextMeshPro>(true);
            details = GetComponentInChildren<ConsoleItemDetail>(true);
            animator = GetComponent<Animator>();
            animator.SetTrigger("Add");
            details.gameObject.SetActive(false);

            OnClick += delegate (ActionableObject o) 
            {
                if (console.activeDetailPanel == null)
                {
                    console.activeDetailPanel = details;
                    details.remainOpen = true;
                    details.Enable();
                }
                else if (console.activeDetailPanel == details)
                {
                    console.activeDetailPanel = null;
                    details.remainOpen = false;
                    details.Disable();
                }
                else if (console.activeDetailPanel != details)
                {
                    console.activeDetailPanel.remainOpen = false;
                    console.activeDetailPanel.Disable();
                    console.activeDetailPanel = details;
                    details.Enable();
                }
            };
            OnHoverEnter += delegate (ActionableObject o)
            {
                if (console.activeDetailPanel == null)
                {
                    details.Enable();
                }
            };
            OnHoverExit += delegate (ActionableObject o)
            {
                if (console.activeDetailPanel == null)
                {
                    details.Disable();
                }
            };

            tmpro.SetText(debugString);
            details.SetMessage(debugString);
            details.SetStackTrace(data);
            // format + cutoff text
        }

    }

}