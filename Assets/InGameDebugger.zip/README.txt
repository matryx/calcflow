1) Replace your Logs.cs with this Logs.cs
2) PlayDebug.cs can go anywhere, Core folder is where we have it.
3) VRDebugConsole, ConsoleItem, ConsoleItemDetail runs the UI.
4) Main prefab is Nanome-DebugConsole, just drag into the scene and deactivate it.
5) To open the console you'll need to create your own button to open the console that runs the line:
	publish("DebugConsole", "ToggleConsole");
6) ConsoleItem contains just the debug message from logs.debug while ConsoleItemDetails contains the full log, feel free to
modify these if there's any problems	
