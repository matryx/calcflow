﻿using System.Collections.Generic;
using System.Text.RegularExpressions;

using Nanome.Core.Extension;

namespace Nanome.Core
{

    public static class PlayDebug
    {

        public delegate void PlayDebugMessageDelegate(object[] payload);
        public static event PlayDebugMessageDelegate OnNewLog;

        public static void PrintStackTrace(string debugString)
        {
            var st = System.Environment.StackTrace;
            var stOrganizedInfo = Format(st);
            var payload = new object[2] { debugString, stOrganizedInfo };
            if (OnNewLog != null)
            {
                OnNewLog.Invoke(payload);
            }
        }

        static List<Tuple<string, string, string>> Format(string raw)
        {
            var lines = raw.Split("\n");
            //Debug.Log("Raw stack trace:\n" + raw);
            // Carries class name, full file path, explicit file name, line number
            var categorizedLines = new List<Tuple<string, string, string>>();
            for (int i = 0; i < lines.Length; i++)
            {
                var className = "";
                var filePath = "";
                var lineNum = "";
                // Trim beginning of stacktrace messages
                if (lines[i].StartsWith("   at"))
                {
                    // Trim off '   at'
                    var length = lines[i].Length;
                    if (length < 0)
                    {
                        continue;
                    }
                    lines[i] = lines[i].Substring(6, length - 6);

                    // Isolate class
                    var endOfClassNameIndex = lines[i].IndexOf(')');
                    var endOfClassNameNoParamIndex = lines[i].IndexOf('(');
                    if (endOfClassNameIndex < 0 || endOfClassNameNoParamIndex < 0)
                    {
                        continue;
                    }
                    //className = lines[i].Substring(0, endOfClassNameIndex + 1);
                    className = lines[i].Substring(0, endOfClassNameNoParamIndex);

                    // Isolate file path
                    var lineNumIndex = lines[i].IndexOf(":line");
                    if (lineNumIndex < 0)
                    {
                        continue;
                    }
                    filePath = lines[i].Substring(endOfClassNameIndex + 5, lineNumIndex - endOfClassNameIndex - 5);

                    // Isolate line #
                    lineNum = lines[i].Substring(lineNumIndex + 1, lines[i].Length - lineNumIndex - 1);
                    categorizedLines.Add(Tuple.Create(className, lineNum, @filePath));
                }

            }
            return categorizedLines;
        }
        // TODO: Might need a Full/Condensed info. Full includes every tuple in stacktrace
        //       Condensed only contains the first tuple

    }

}
