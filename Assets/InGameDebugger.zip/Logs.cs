using UnityEngine;

using System;

using Nanome.Core.Extension;

namespace Nanome.Core
{

    public class Logs
    {

        private sealed class LogType
        {
            public static readonly LogType DEBUG = new LogType(0, "DEBUG", Color.blue);
            public static readonly LogType INFO = new LogType(1, "INFO", Color.green);
            public static readonly LogType WARNING = new LogType(2, "WARNING", Color.yellow);
            public static readonly LogType EXCEPTION = new LogType(3, "EXCEPTION", Color.red);
            public static readonly LogType ERROR = new LogType(4, "ERROR", Color.red);

            public readonly int priority;
            public readonly string name;
            public readonly Color color;

            private LogType(int priority, string name, Color color)
            {
                this.priority = priority;
                this.name = name;
                this.color = color;
            }
        }

        private static string logFileToday = string.Format("{0:yyyy-MM-dd_HH-mm-ss}", DateTime.Now);

        private static string localLogDirectory()
        {
            return File.Path.inStorage("./History/");
        }

        private static string localLogMessagesPath()
        {
            return File.Path.inStorage("./History/" + logFileToday + "_messages.txt");
        }

        private static string localLogDetailsPath()
        {
            return File.Path.inStorage("./History/" + logFileToday + "_details.txt");
        }

        public static string localHistoryDetailsPath()
        {
            return File.Path.inStorage("./History/" + logFileToday + "_channels.txt");
        }

        private static string wrapColor(string str, Color color)
        {
            var fcolor = Color.black.blend(color, 0.4f);
            if (Nanome.Core.Daemon.Logging.isDarkTheme)
            {
                fcolor = Color.white.blend(color, 0.4f);
            }
            return "<color=" + fcolor.toString() + ">" + str + "</color>";
        }

        private static string magicColor(string str)
        {
            if (str.Length > 50)
            {
                return str;
            }
            var hue = Math.Abs(str.GetHashCode()) % 1000f / 1000f;
            var color = Color.HSVToRGB(hue, 1f, 1f);
            return wrapColor(str, color);
        }

        static private void format(LogType type, object[] list, int severity)
        {
            // We might want to disable all debug sometimes
            if (disableLogs)
            {
                return;
            }
            // Might be refactored for a simpler/faster implementation, but it works for now so whatever :)
            string editorLine = "";
            string fileLine = "";
            editorLine += Logs.wrapColor("[" + type.name + "] - ", type.color);
            fileLine += "[" + type.name + "] - ";
            for (int i = 0; i < list.Length; i++)
            {
                if (i > 0)
                {
                    editorLine += " ";
                    fileLine += " ";
                }
                object elem = list[i];
                if (elem != null)
                {
                    editorLine += Logs.magicColor(list[i].ToString());
                    fileLine += list[i].ToString();
                }
                else
                {
                    editorLine += Logs.magicColor("NULL");
                    fileLine += "NULL";
                }
            }
            // We might need it later on to centralize the debugging on a server
            if (Nanome.Core.Daemon.Logging.isEditor)
            {
                if (severity == 2)
                {
                    Debug.LogError(editorLine);
                }
                else if (severity == 1)
                {
                    Debug.LogWarning(editorLine);
                }
                else
                {
                    Debug.Log(editorLine);
                }

                PlayDebug.PrintStackTrace(editorLine);
            }
            else
            {
                // For now we can disable logging to the console when in builds
                // We are using the filesystem log for build debugging, more precise
                // Debug.Log(fileLine);
            }
            // It might be usefull to diagnose customers errors remotely
            // Lets also save it on disk right now, just in case
            try
            {
                var code = "";
                var here = Environment.StackTrace.Split("\n");
                if (here.Length >= 4)
                {
                    code = here[3];
                    var parts = code.Split(" in ");
                    if (parts.Length >= 2)
                    {
                        code = parts[1].Trim();
                    }
                }
                Async.runInMain(delegate (Async a)
                {
                    File.ensureFolderExists(Logs.localLogDirectory());
                    var messagesPath = Logs.localLogMessagesPath();
                    var detailsPath = Logs.localLogDetailsPath();
                    var writeMessage = string.Format("{0:u}", DateTime.Now) + " - " + fileLine + Environment.NewLine;
                    Nanome.Core.Daemon.Logging.ScheduleForLogging(messagesPath, writeMessage);
                    // File.writeFileAppend(messagesPath, writeMessage);
                    if (code.Length > 0)
                    {
                        var writeDetails = writeMessage + " --> " + code + Environment.NewLine + Environment.NewLine;
                        Nanome.Core.Daemon.Logging.ScheduleForLogging(detailsPath, writeDetails);
                        // File.writeFileAppend(detailsPath, writeDetails);
                    }
                });
            }
            catch (Exception e)
            {
                Debug.Log("Coult not log to history files:");
                Debug.Log(e);
                // If the logging failed, there is not much we can do
            }
        }

        static public void timed(params object[] list)
        {
            var nlist = new object[list.Length + 1];
            nlist[0] = string.Format("{0:HH':'mm':'ss'.'fff}", DateTime.Now);
            list.CopyTo(nlist, 1);
            Nanome.Core.Logs.format(LogType.DEBUG, nlist, 0);
        }

        static public void debug(params object[] list)
        {
            Nanome.Core.Logs.format(LogType.DEBUG, list, 0);
        }

        static public void info(params object[] list)
        {
            Nanome.Core.Logs.format(LogType.INFO, list, 0);
        }

        static public void warning(params object[] list)
        {
            Nanome.Core.Logs.format(LogType.WARNING, list, 1);
        }

        static public void exception(params object[] list)
        {
            Nanome.Core.Logs.format(LogType.EXCEPTION, list, 2);
        }

        static public void error(params object[] list)
        {
            Nanome.Core.Logs.format(LogType.ERROR, list, 2);
        }

        static private readonly bool disableLogs = false;

    }

}
